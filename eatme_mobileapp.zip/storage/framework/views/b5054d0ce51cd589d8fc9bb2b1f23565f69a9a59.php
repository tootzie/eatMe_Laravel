<!DOCTYPE html>
<html>
<head>
    <title>eatMe! Mobile Application</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
   
    <br/>
    <p><b>eatMe! Team</b></p>
</body>
</html><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/email/complain.blade.php ENDPATH**/ ?>