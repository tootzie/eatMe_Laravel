

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Bisnis Kuliner</h1>
  </div>

  <?php if(\Session::has('success')): ?>
  <div class="alert alert-success">
      <ul>
          <li><?php echo \Session::get('success'); ?></li>
      </ul>
  </div>
  <?php endif; ?>
  <br/>

  

  <form action="/dashboard/bisnis/create" method="GET" class="d-inline">
    <?php echo csrf_field(); ?>
    <button class=" btn btn-success border-0">Tambah Bisnis</button>
  </form>  
  
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Bisnis</th>
        <th scope="col">ID Pemilik Bisnis</th>
        <th scope="col">Nama</th>
        <th scope="col">Alamat</th>
        <th scope="col">Nomor Telp</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><?php echo e($business->id); ?></td>
        <td><?php echo e($business->id_pemilik_bisnis_kuliner); ?></td>
        <td><?php echo e($business->nama_bisnis); ?></td>
        <td><?php echo e($business->alamat_bisnis); ?></td>
        <td><?php echo e($business->no_telp); ?></td>
        <td>
            
            <a href="/dashboard/bisnis/<?php echo e($business->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
            <form action="/dashboard/bisnis/<?php echo e($business->id); ?>/edit" method="GET" class="d-inline">
                <?php echo csrf_field(); ?>
                <button class=" badge bg-warning border-0"><span data-feather="edit"></span></button>
            </form>
            <form action="<?php echo e(route('bisnis.destroy',$business->id)); ?>" method="POST" class="d-inline">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button class=" badge bg-danger border-0" onclick="return confirm('Hapus bisnis?')"><span data-feather="trash-2"></span></button>
            </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/bisnis/index.blade.php ENDPATH**/ ?>