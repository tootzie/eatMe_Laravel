

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Komplain</h1>
  </div>

  <br/>
  <h4>Belum Diproses</h4>

  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Transaksi (Nota)</th>
        <th scope="col">ID User (Konsumen)</th>
        <th scope="col">ID Bisnis Kuliner</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $complains_belumproses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><a href="/dashboard/transaksi/<?php echo e($complain->id); ?>"><?php echo e($complain->id); ?></a></td>
        <td><a href="/dashboard/user/<?php echo e($complain->id_user); ?>"><?php echo e($complain->id_user); ?></a></td>
        <td><a href="/dashboard/bisnis/<?php echo e($complain->id_bisnis_kuliner); ?>"><?php echo e($complain->id_bisnis_kuliner); ?></a></td>
        
        <td>
            <a href="/dashboard/komplain/<?php echo e($complain->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
            <form action="/dashboard/komplain/konfirmasi/<?php echo e($complain->id); ?>" method="POST" class="d-inline">
              <?php echo method_field('PUT'); ?>
              <?php echo csrf_field(); ?>
              <button class="badge bg-warning border-0" onclick="return confirm('Tandai komplain sedang diproses?')"><span data-feather="check"></span></button>
            </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <br/>
  <h4>Sedang Diproses</h4>

  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Transaksi (Nota)</th>
        <th scope="col">ID User (Konsumen)</th>
        <th scope="col">ID Bisnis Kuliner</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $complains_sedangproses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><a href="/dashboard/transaksi/<?php echo e($complain->id); ?>"><?php echo e($complain->id); ?></a></td>
        <td><a href="/dashboard/user/<?php echo e($complain->id_user); ?>"><?php echo e($complain->id_user); ?></a></td>
        <td><a href="/dashboard/bisnis/<?php echo e($complain->id_bisnis_kuliner); ?>"><?php echo e($complain->id_bisnis_kuliner); ?></a></td>
        
        <td>
            <a href="/dashboard/komplain/<?php echo e($complain->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
            <form action="/dashboard/komplain/konfirmasi/<?php echo e($complain->id); ?>" method="POST" class="d-inline">
              <?php echo method_field('PUT'); ?>
              <?php echo csrf_field(); ?>
              <button class="badge bg-success border-0" onclick="return confirm('Selesaikan komplain?')"><span data-feather="check"></span></button>
            </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <br/>
  <h4>Komplain Selesai</h4>

  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Transaksi (Nota)</th>
        <th scope="col">ID User (Konsumen)</th>
        <th scope="col">ID Bisnis Kuliner</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $complains_selesai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><a href="/dashboard/transaksi/<?php echo e($complain->id); ?>"><?php echo e($complain->id); ?></a></td>
        <td><a href="/dashboard/user/<?php echo e($complain->id_user); ?>"><?php echo e($complain->id_user); ?></a></td>
        <td><a href="/dashboard/bisnis/<?php echo e($complain->id_bisnis_kuliner); ?>"><?php echo e($complain->id_bisnis_kuliner); ?></a></td>
        
        <td>
            <a href="/dashboard/komplain/<?php echo e($complain->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/komplain/index.blade.php ENDPATH**/ ?>