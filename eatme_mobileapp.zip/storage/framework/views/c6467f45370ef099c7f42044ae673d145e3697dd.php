

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Bisnis #<?php echo e($business->id); ?></h1>
  </div>

  

  <div class="modal-body row">
    <div class="col-md-6">
        <br/>
        <h5>Bisnis</h5>
        <h6><?php echo e($business->id); ?> - <?php echo e($business->nama_bisnis); ?></h6>

        <br/>
        <h5>Foto Bisnis</h5>
        <?php if($business->foto_profil != null): ?>
            <img src="<?php echo e(url('storage/'.$business->foto_profil)); ?>" class="img-fluid " alt="Foto Profil Bisnis" style="max-width: 50%; max-height: 50%;">
        <?php else: ?> 
            <h6>Tidak ada foto</h6>
        <?php endif; ?>

        <br/>
        <h5>Alamat Bisnis</h5>
        <h6><?php echo e($business->alamat_bisnis); ?></h6>
        
        <br/>
        <h5>Nomor Telepon</h5>
        <h6><?php echo e($business->no_telp); ?></h6>
        
        <br/>
        <h5>Kategori Makanan</h5>
        <h6><?php echo e($business->kategori_makanan); ?></h6>
        
        <br/>
        <h5>Jam Pengambilan</h5>
        <h6><?php echo e($jamAwal); ?> - <?php echo e($jamAkhir); ?></h6>
        
        <br/>
        <h5>Status Validasi</h5>
        <?php if( $business->status_validasi == 1 ): ?>
            <h6> Bisnis tervalidasi </h6>
        <?php else: ?> 
            <h6> Bisnis belum tervalidasi </h6>
        <?php endif; ?>
        
        <br/>
        <h5>Status Bisnis</h5>
        <?php if($business->status_bisnis == 1): ?>
            <h6> Buka </h6>
        <?php else: ?> 
            <h6> Tutup </h6>
        <?php endif; ?>

        <br/>
        <h5>Rating Bisnis</h5>
        <h6><?php echo e($business->rating_bisnis); ?></h6>
        
    </div>

    <div class="col-md-6">
        
        <br/>
        <h5>Pemilik</h5>
        <h6><?php echo e($pemilik->id); ?> - <?php echo e($pemilik->nama_pemilik); ?></h6>
        
        <br/>
        <h5>ID User</h5>
        <h6><a href="/dashboard/user/<?php echo e($pemilik->id_user); ?>"><?php echo e($pemilik->id_user); ?></a></h6>
        
        <br/>
        <h5>No KTP</h5>
        <h6><?php echo e($pemilik->no_ktp); ?></h6>

        <br/>
        <h5>Alamat Pemilik</h5>
        <h6><?php echo e($pemilik->alamat_pemilik); ?></h6>
        
        <br/>
        <h5>No Telp</h5>
        <h6><?php echo e($pemilik->no_telp); ?></h6>

        <br/>
        <h5>Email Pemilik</h5>
        <h6><?php echo e($pemilik->email_pemilik); ?></h6>

        <br/>
        <h5>No Rekening</h5>
        <h6><?php echo e($pemilik->no_rekening); ?></h6>

        <br/>
        <h5>Nama Rekening</h5>
        <h6><?php echo e($pemilik->nama_rekening); ?></h6>

        <br/>
        <h5>Bank Rekening</h5>
        <h6><?php echo e($pemilik->bank_rekening); ?></h6>

        <br/><br/>
        
        
    </div>
  </div>


  

  <br/><br/>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/bisnis/show.blade.php ENDPATH**/ ?>