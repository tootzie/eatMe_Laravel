

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">User</h1>
  </div>
  <br/>
  
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID User</th>
        <th scope="col">Nama</th>
        <th scope="col">Email</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><?php echo e($user->id); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td>
            
            <a href="/dashboard/user/<?php echo e($user->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
            <form action="/dashboard/user/<?php echo e($user->id); ?>/edit" method="GET" class="d-inline">
                <?php echo csrf_field(); ?>
                <button class=" badge bg-warning border-0"><span data-feather="edit"></span></button>
            </form>
            <form action="<?php echo e(route('user.destroy',$user->id)); ?>" method="POST" class="d-inline">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button class=" badge bg-danger border-0" onclick="return confirm('Hapus user?')"><span data-feather="trash-2"></span></button>
            </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/user/index.blade.php ENDPATH**/ ?>