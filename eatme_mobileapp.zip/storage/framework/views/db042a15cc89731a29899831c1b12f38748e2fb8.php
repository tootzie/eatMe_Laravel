



<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Komplain (ID Transaksi (Nota): <a href="/dashboard/transaksi/<?php echo e($nota->id); ?>"><?php echo e($nota->id); ?></a></h1>
  </div>
  <br/>
  <div class="modal-body row">
    <div class="col-md-6">

        <h3> Pihak User </h3>
        <?php if($complain_user->count() == 0): ?>
          <br/>
          <h5> User tidak mengajukan komplain </h5>
        <?php else: ?>
          <br/>
          <h5>User</h5>
          <h6><td><a href="/dashboard/user/<?php echo e($user->id); ?>"><?php echo e($user->id); ?> - <?php echo e($user->name); ?></a></td></h6>

          <br/>
          <h5>Email User</h5>
          <h6><?php echo e($user->email); ?></h6>

          <br/>
          <h5>Deskripsi Komplain</h5>
          <h6><?php echo e($complain_user[0]->deskripsi_komplain); ?></h6>

          <?php if($complain_user[0]->gambar_komplain == null): ?>
            <br/>
            <h5>Gambar Komplain</h5>
            <h6>Tidak ada gambar</h6>
          <?php else: ?>
            <br/>
            <h5>Gambar Komplain</h5>
            <img src="<?php echo e(url('storage/'.$complain_user[0]->gambar_komplain)); ?>" class="img-fluid " alt="Foto KTP" style="max-width: 50%; max-height: 50%;">
          <?php endif; ?>
        <?php endif; ?>
    </div>

    <div class="col-md-6">

      <h3> Pihak Bisnis </h3>

      <?php if($complain_bisnis->count() == 0): ?>
        <br/>
        <h5> Bisnis kuliner tidak mengajukan komplain </h5>
      <?php else: ?>
      
        <br/>
        <h5>Bisnis</h5>
        <h6><a href="/dashboard/bisnis/<?php echo e($bisnis->id); ?>"><?php echo e($bisnis->id); ?> - <?php echo e($bisnis->nama_bisnis); ?></a></h6>
        
        <br/>
        <h5>Pemilik Bisnis</h5>
        <h6><?php echo e($pemilik_bisnis->id); ?> - <?php echo e($pemilik_bisnis->nama_pemilik); ?></h6>
        
        <br/>
        <h5>Email Pemilik</h5>
        <h6><?php echo e($pemilik_bisnis->email_pemilik); ?></h6>

        <br/>
        <h5>Deskripsi Komplain</h5>
        <h6><?php echo e($complain_bisnis[0]->deskripsi_komplain); ?></h6>

        <?php if($complain_bisnis[0]->gambar_komplain == null): ?>
          <br/>
          <h5>Gambar Komplain</h5>
          <h6>Tidak ada gambar</h6>
        <?php else: ?>
          <br/>
          <h5>Gambar Komplain</h5>
          <img src="<?php echo e(url('storage/'.$complain_bisnis[0]->gambar_komplain)); ?>" class="img-fluid " alt="Foto KTP" style="max-width: 50%; max-height: 50%;">
        <?php endif; ?>
      <?php endif; ?>

      <br/>
      
      <?php if($nota->status_komplain == 1): ?>
        <form action="/dashboard/komplain/konfirmasi/<?php echo e($nota->id); ?>" method="POST">
          <?php echo method_field('PUT'); ?>
          <?php echo csrf_field(); ?>
          <button class="btn btn-warning border-0" onclick="return confirm('Tandai komplain sedang diproses?')">Tandai Sedang Diproses</button>
        </form>
      <?php elseif($nota->status_komplain == 11): ?>
        <form action="/dashboard/komplain/konfirmasi/<?php echo e($nota->id); ?>" method="POST">
          <?php echo method_field('PUT'); ?>
          <?php echo csrf_field(); ?>
          <button class="btn btn-success border-0" onclick="return confirm('Selesaikan komplain?')">Selesaikan Komplain</button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  

  <br/><br/>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/komplain/show.blade.php ENDPATH**/ ?>