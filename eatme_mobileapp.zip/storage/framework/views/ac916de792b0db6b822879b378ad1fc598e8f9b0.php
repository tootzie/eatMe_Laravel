

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Transaksi (ID: <?php echo e($transaction->id); ?>)</h1>
  </div>

  <br/>
  <h6>User: <a href="/dashboard/user/<?php echo e($user->id); ?>"><?php echo e($user->id); ?> - <?php echo e($user->name); ?></a></h6>
  <h6>Bisnis Kuliner: <a href="/dashboard/bisnis/<?php echo e($bisniskuliner->id); ?>"><?php echo e($bisniskuliner->id); ?> - <?php echo e($bisniskuliner->nama_bisnis); ?></a></h6>

  <br/><br/>
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Menu</th>
        <th scope="col">Nama Menu</th>
        <th scope="col">Harga Menu</th>
        <th scope="col">Jumlah Makanan</th>
        <th scope="col">Catatan Makanan</th>
        <th scope="col">Harga Total</th>
        <th scope="col">Tanggal Pemesanan</th>
        
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><?php echo e($order->id_menu); ?></td>
        <td><?php echo e($order->nama_makanan); ?></td>
        <td>Rp. <?php echo number_format($order->harga_makanan,0,',','.'); ?></td>
        <td><?php echo e($order->jumlah_makanan); ?></td>
        <td><?php echo e($order->catatan_makanan); ?></td>
        <td>Rp. <?php echo number_format($order->jumlah_makanan*$order->harga_makanan,0,',','.'); ?></td>
        <td><?php echo e($order->tanggal_pemesanan); ?></td>
        
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <br/>
  <h6>Total Transaksi: Rp. <?php echo number_format($transaction->total_harga,0,',','.'); ?> </h6>
      
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/transaksi/show.blade.php ENDPATH**/ ?>