<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>