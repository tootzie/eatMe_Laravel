use App\Http\Controllers\DashboardEwalletController;



<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Form Validasi (ID: <?php echo e($form->id); ?>)</h1>
  </div>

  

  <div class="modal-body row">
    <div class="col-md-6">
        <br/>
        <h5>User</h5>
        <h6><a href="/dashboard/user/<?php echo e($form->id_user); ?>"><?php echo e($form->id_user); ?> - <?php echo e($user->name); ?></a></h6>

        <br/>
        <h5>Nama Bisnis</h5>
        <h6><?php echo e($form->nama_bisnis); ?></h6>

        <br/>
        <h5>Alamat Bisnis</h5>
        <h6><?php echo e($form->alamat_bisnis); ?></h6>

        <br/>
        <h5>Nama Pemilik</h5>
        <h6><?php echo e($form->nama_pemilik); ?></h6>

        <br/>
        <h5>Nomor KTP</h5>
        <h6><?php echo e($form->no_ktp); ?></h6>

        <br/>
        <h5>Alamat Pemilik</h5>
        <h6><?php echo e($form->alamat_pemilik); ?></h6>

        <br/>
        <h5>Nomor Telepon Pemilik</h5>
        <h6><?php echo e($form->no_telp_pemilik); ?></h6>

        <br/>
        <h5>Email Pemilik</h5>
        <h6><?php echo e($form->email_pemilik); ?></h6>

        <br/>
        <h5>Foto KTP</h5>
        <img src="<?php echo e(url('storage/'.$form->foto_ktp)); ?>" class="img-fluid " alt="Foto KTP" style="max-width: 50%; max-height: 50%;">

        <br/><br/>
        <h5>Foto Selfie dengan KTP</h5>
        <img src="<?php echo e(url('storage/'.$form->foto_selfie_ktp)); ?>" class="img-fluid " alt="Foto KTP" style="max-width: 50%; max-height: 50%;">
    </div>

    <div class="col-md-6">
        <br/>
        <h5>Nomor Rekening</h5>
        <h6><?php echo e($form->no_rekening); ?></h6>

        <br/>
        <h5>Nama Rekening</h5>
        <h6><?php echo e($form->nama_rekening); ?></h6>

        <br/>
        <h5>Nama Bank Rekening</h5>
        <h6><?php echo e($form->bank_rekening); ?></h6>

        <br/><br/>
        <?php if($form->validasi_admin != 1): ?>
            <form action="/dashboard/validasibisnis/konfirmasi/<?php echo e($form->id); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <button class="btn btn-success border-0" onclick="return confirm('Validasi sekarang?')">Validasi Sekarang</button>
            </form>
        <?php else: ?>
        <form action="/dashboard/validasibisnis/konfirmasi/<?php echo e($form->id); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger border-0" onclick="return confirm('Batalkan validasi?')">Batalkan Validasi</button>
        </form>
        <?php endif; ?>
        
    </div>
  </div>


  

  <br/><br/>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/validasibisnis/show.blade.php ENDPATH**/ ?>