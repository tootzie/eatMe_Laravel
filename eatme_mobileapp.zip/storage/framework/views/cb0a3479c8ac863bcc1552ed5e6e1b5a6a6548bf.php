

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">E-Wallet</h1>
  </div>

  <br/>
  <h4>Permintaan Top-Up</h4>
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Top-Up</th>
        <th scope="col">ID User</th>
        <th scope="col">Jumlah Transaksi</th>
        <th scope="col">Tanggal Permintaan Top-Up</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $ewallets_topup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ewallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><?php echo e($ewallet->id); ?></td>
        <td><a href="/dashboard/user/<?php echo e($ewallet->id_user); ?>"><?php echo e($ewallet->id_user); ?></a></td>
        <td>Rp. <?php echo number_format($ewallet->jumlah_transaksi,0,',','.'); ?></td>
        <td><?php echo e($ewallet->tanggal_transaksi); ?></td>
        <td>
            <a href="/dashboard/ewallet/<?php echo e($ewallet->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <br/>
  <h4>Riwayat Top-Up</h4>
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Top-Up</th>
        <th scope="col">ID User</th>
        <th scope="col">Jumlah Transaksi</th>
        <th scope="col">Tanggal Permintaan Top-Up</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $ewallets_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ewallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><?php echo e($ewallet->id); ?></td>
        <td><a href="/dashboard/user/<?php echo e($ewallet->id_user); ?>"><?php echo e($ewallet->id_user); ?></a></td>
        <td>Rp. <?php echo number_format($ewallet->jumlah_transaksi,0,',','.'); ?></td>
        <td><?php echo e($ewallet->tanggal_transaksi); ?></td>
        <td>
            <a href="/dashboard/ewallet/<?php echo e($ewallet->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <br/>
  <h4>Saldo User</h4>
  <form action="/dashboard/ewallet/create" method="GET" class="d-inline">
    <?php echo csrf_field(); ?>
    <button class=" btn btn-primary border-0">Tambah/Kurang Saldo</button>
  </form>
  <br/><br/>
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID User</th>
        <th scope="col">Nama</th>
        <th scope="col">Saldo E-Wallet</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><a href="/dashboard/user/<?php echo e($user->id); ?>"><?php echo e($user->id); ?></a></td>
        <td><?php echo e($user->name); ?></td>
        <td>Rp. <?php echo number_format($user->saldo_ewallet,0,',','.'); ?></td>
        <td>
            
            <a href="/dashboard/ewallet/<?php echo e($user->id); ?>/edit" class="badge bg-warning"><span data-feather="edit"></span></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/ewallet/index.blade.php ENDPATH**/ ?>