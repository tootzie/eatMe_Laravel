

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Pendapatan</h1>
  </div>

  <div class="my-2">
    <form action="/dashboard/pendapatan" method="GET">
      <?php echo csrf_field(); ?>
        <div class="input-group mb-3">
            <input type="date" class="form-control" name="start_date" value="<?php echo e($tanggal_awal); ?>">
            <input type="date" class="form-control" name="end_date" value="<?php echo e($tanggal_akhir); ?>">
        </div>
        <div class="input-group mb-3">
          <input type="number," class="form-control" id="id_bisnis" name="id_bisnis" placeholder="ID Bisnis" value=<?php echo e($id_bisnis); ?>>
        </div>
        <button class="btn btn-primary" type="submit">FILTER</button>
    </form>
  </div>

  <br/>
  <h4>Belum Transfer</h4>
  <?php if($incomes_notf == 'Not Found'): ?>
    <h5>Data Tidak Ditemukan</h5>
  <?php else: ?>
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">ID Pendapatan</th>
          <th scope="col">ID Bisnis Kuliner</th>
          <th scope="col">ID Transaksi (Nota)</th>
          <th scope="col">Total Transaksi</th>
          <th scope="col">Komisi</th>
          <th scope="col">Pendapatan Bersih</th>
          <th scope="col">Tanggal Transaksi</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $incomes_notf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop -> iteration); ?></td>
          <td><?php echo e($income->id); ?></td>
          <td><a href="/dashboard/bisnis/<?php echo e($income->id_bisnis_kuliner); ?>"><?php echo e($income->id_bisnis_kuliner); ?></a></td>
          <td><a href="/dashboard/transaksi/<?php echo e($income->id_nota); ?>"><?php echo e($income->id_nota); ?></a></td>
          <td>Rp. <?php echo number_format($income->total_harga,0,',','.'); ?></td>
          <td>Rp. <?php echo number_format($income->komisi,0,',','.'); ?></td>
          <td>Rp. <?php echo number_format($income->pendapatan_bersih,0,',','.'); ?></td>
          <td><?php echo e($income->tanggal_pendapatan); ?></td>
          
          <td>
              <form action="/dashboard/pendapatan/konfirmasi/<?php echo e($income->id); ?>" method="POST" class="d-inline">
                  <?php echo method_field('PUT'); ?>
                  <?php echo csrf_field(); ?>
                  <button class=" badge bg-success border-0" onclick="return confirm('Tandai sudah di transfer? Bisnis kuliner akan mendapatkan data dana yang sudah ditransfer')" title="sudah ditransfer"><span data-feather="check"></span></button>
              </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  <?php endif; ?>

  <br/>
  <h4>Riwayat Transfer</h4>
  <?php if($incomes_history == 'Not Found'): ?>
    <h5>Data Tidak Ditemukan</h5>
  <?php else: ?>
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">ID Pendapatan</th>
          <th scope="col">ID Bisnis Kuliner</th>
          <th scope="col">ID Transaksi (Nota)</th>
          <th scope="col">Total Transaksi</th>
          <th scope="col">Komisi</th>
          <th scope="col">Pendapatan Bersih</th>
          <th scope="col">Tanggal Transaksi</th>
          
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $incomes_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop -> iteration); ?></td>
          <td><?php echo e($income->id); ?></td>
          <td><a href="/dashboard/bisnis/<?php echo e($income->id_bisnis_kuliner); ?>"><?php echo e($income->id_bisnis_kuliner); ?></a></td>
          <td><a href="/dashboard/transaksi/<?php echo e($income->id_nota); ?>"><?php echo e($income->id_nota); ?></a></td>
          <td>Rp. <?php echo number_format($income->total_harga,0,',','.'); ?></td>
          <td>Rp. <?php echo number_format($income->komisi,0,',','.'); ?></td>
          <td>Rp. <?php echo number_format($income->pendapatan_bersih,0,',','.'); ?></td>
          <td><?php echo e($income->tanggal_pendapatan); ?></td>
          
          <td>
              
              <form action="/dashboard/pendapatan/konfirmasi/<?php echo e($income->id); ?>" method="POST" class="d-inline">
                  <?php echo method_field('PUT'); ?>
                  <?php echo csrf_field(); ?>
                  <button class=" badge bg-danger border-0" onclick="return confirm('Kembalikan ke daftar belum transfer?')" title="kembalikan ke daftar belum transfer"><span data-feather="x-circle"></span></button>
              </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/pendapatan/index.blade.php ENDPATH**/ ?>