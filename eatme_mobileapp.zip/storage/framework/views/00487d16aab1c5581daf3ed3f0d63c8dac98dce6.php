

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Top-Up</h1>
  </div>

  <br/>
  <h6>User          : <a href="/dashboard/user/<?php echo e($ewallet->id_user); ?>"><?php echo e($ewallet->id_user); ?> - <?php echo e($user->name); ?></a></h6>
  <h6>Jumlah top-up : Rp. <?php echo number_format($ewallet->jumlah_transaksi,0,',','.'); ?></h6>
  <h6>Bukti Transfer</h6>
  <img src="<?php echo e(url('storage/'.$ewallet->bukti_transfer)); ?>" class="img-fluid " alt="Bukti Transfer" style="max-width: 50%; max-height: 50%;">

  <br/><br/>

  <?php if($ewallet->status_topup == 0): ?>
    <form action="/dashboard/ewallet/<?php echo e($ewallet->id); ?>" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <button class="btn btn-success border-0" onclick="return confirm('Top-up sebesar Rp. <?php echo number_format($ewallet->jumlah_transaksi,0,',','.'); ?> kepada <?php echo e($user->name); ?>?')">Top-up Sekarang</button>
    </form>
  <?php else: ?>
    <h5>TOP-UP BERHASIL</h5>
  <?php endif; ?>
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/ewallet/show.blade.php ENDPATH**/ ?>