



<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Validasi Bisnis Kuliner</h1>
  </div>

  <br/>
  <h4>Perlu Validasi</h4>
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Form</th>
        <th scope="col">ID User</th>
        <th scope="col">Nama Bisnis</th>
        <th scope="col">Nama Pemilik</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $forms_unvalidated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><?php echo e($form->id); ?></td>
        <td><a href="/dashboard/user/<?php echo e($form->id_user); ?>"><?php echo e($form->id_user); ?></a></td>
        <td><?php echo e($form->nama_bisnis); ?></td>
        <td><?php echo e($form->nama_pemilik); ?></td>
        <td>
            <a href="/dashboard/validasibisnis/<?php echo e($form->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
            <form action="/dashboard/validasibisnis/konfirmasi/<?php echo e($form->id); ?>" method="POST" class="d-inline">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <button class=" badge bg-success border-0" onclick="return confirm('Validasi sekarang?')" title="validasi"><span data-feather="check"></span></button>
            </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <br/>
  
  <h4>Sudah Tervalidasi </h4>
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">ID Form</th>
        <th scope="col">ID User</th>
        <th scope="col">Nama Bisnis</th>
        <th scope="col">Nama Pemilik</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $forms_validated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop -> iteration); ?></td>
        <td><?php echo e($form->id); ?></td>
        <td><a href="/dashboard/user/<?php echo e($form->id_user); ?>"><?php echo e($form->id_user); ?></a></td>
        <td><?php echo e($form->nama_bisnis); ?></td>
        <td><?php echo e($form->nama_pemilik); ?></td>
        <td>
            
            <a href="/dashboard/validasibisnis/<?php echo e($form->id); ?>" class="badge bg-primary"><span data-feather="eye"></span></a>
            <form action="/dashboard/validasibisnis/konfirmasi/<?php echo e($form->id); ?>" method="POST" class="d-inline">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <button class=" badge bg-danger border-0" onclick="return confirm('Batalkan validasi?')" title="batalkan validasi"><span data-feather="x-circle"></span></button>
            </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/validasibisnis/index.blade.php ENDPATH**/ ?>