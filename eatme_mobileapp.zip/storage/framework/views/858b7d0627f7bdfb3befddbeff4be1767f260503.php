

<?php $__env->startSection('container'); ?>
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit User</h1>
  </div>

  <div class="col-lg-8">
    <form  action="/dashboard/user/<?php echo e($user->id); ?>" method="POST">
      <?php echo method_field('PUT'); ?>
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="name">Nama User</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
      </div>
      <div class="form-group">
        <label for="email">Email User</label>
        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
      </div>
      <div class="form-group">
        <label for="rating_user">Rating User</label>
        <input type="number" class="form-control" id="rating_user" name="rating_user" value="<?php echo e($user->rating_user); ?>">
      </div>
      <div class="form-group">
        <label for="makanan_diselamatkan">Makanan Diselamatkan</label>
        <input type="number" class="form-control" id="makanan_diselamatkan" name="makanan_diselamatkan" value="<?php echo e($user->makanan_diselamatkan); ?>">
      </div>
      <div class="form-group">
        <label for="saldo_ewallet">Saldo E-Wallet</label>
        <input type="number" class="form-control" id="saldo_ewallet" name="saldo_ewallet" value="<?php echo e($user->saldo_ewallet); ?>">
      </div>
      <br/>
      <button type="submit" class="btn btn-primary">Edit</button>
    </form>   
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Informatika\SEMESTER 8\Laravel_eatme\eatme_mobileapp\resources\views/dashboard/user/edit.blade.php ENDPATH**/ ?>